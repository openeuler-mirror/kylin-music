#!/bin/bash


rm -f kylin-music.pro.user
