## 拼音文件

wget https://raw.githubusercontent.com/mozillazg/pinyin-data/master/pinyin.txt
